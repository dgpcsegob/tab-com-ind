import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { Sidebar, Menu, MenuItem, SubMenu } from 'react-pro-sidebar';
import './Sidebar.css';

interface SidebarProps {
  layersVisibility: { [layerId: string]: boolean };
  onToggle: (id: string) => void;
  onFilterChange: (filters: FilterState) => void;
  selectedCommunity: CommunityData | null;
  isDarkTheme: boolean;
  onThemeToggle: () => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  onOpenHtmlViewer: (communityId: string, communityName: string) => void;
  onClearSelectedCommunity: () => void;
  extractedData: ExtractedData | null;
}

interface FilterState {
  entidad: string;
  municipio: string;
  comunidad: string;
  pueblo: string;
}

interface CommunityData {
  id: string;
  nombre: string;
  entidad: string;
  municipio: string;
  pueblo: string;
  poblacion: number;
}

interface ExtractedData {
  entidades: Set<string>;
  municipiosPorEntidad: Map<string, Set<string>>;
  comunidadesPorMunicipio: Map<string, Set<string>>;
  pueblos: Set<string>;
  features: any[];
}

const CustomSidebar: React.FC<SidebarProps> = ({
  layersVisibility,
  onToggle,
  onFilterChange,
  selectedCommunity,
  isDarkTheme,
  onThemeToggle,
  collapsed,
  onToggleCollapse,
  onOpenHtmlViewer,
  onClearSelectedCommunity,
  extractedData
}) => {
  const [filters, setFilters] = useState<FilterState>({
    entidad: '',
    municipio: '',
    comunidad: '',
    pueblo: ''
  });

  const [searchTerms, setSearchTerms] = useState({
    entidad: '',
    municipio: '',
    comunidad: '',
    pueblo: ''
  });

  const [showDropdowns, setShowDropdowns] = useState({
    entidad: false,
    municipio: false,
    comunidad: false,
    pueblo: false
  });

  // Referencias para los inputs y dropdowns
  const inputRefs = useRef<{[key: string]: HTMLInputElement | null}>({
    entidad: null,
    municipio: null,
    comunidad: null,
    pueblo: null
  });

  // Función para posicionar dinámicamente los dropdowns
  const positionDropdown = useCallback((field: keyof typeof showDropdowns) => {
    setTimeout(() => {
      const dropdown = document.querySelector(`.dropdown-${field}`) as HTMLElement;
      const input = inputRefs.current[field];
      
      if (dropdown && input) {
        const rect = input.getBoundingClientRect();
        const viewportHeight = window.innerHeight;
        const dropdownHeight = parseInt(getComputedStyle(dropdown).maxHeight) || 240;
        
        // Calcular si hay espacio suficiente abajo
        const spaceBelow = viewportHeight - rect.bottom - 10;
        const spaceAbove = rect.top - 10;
        
        let top: number;
        if (spaceBelow >= dropdownHeight || spaceBelow >= spaceAbove) {
          // Mostrar abajo del input
          top = rect.bottom + 4;
        } else {
          // Mostrar arriba del input
          top = rect.top - dropdownHeight - 4;
        }
        
        // Asegurar que no se salga de la pantalla
        top = Math.max(10, Math.min(top, viewportHeight - dropdownHeight - 10));
        
        dropdown.style.top = `${top}px`;
        dropdown.style.left = `${rect.left}px`;
        dropdown.style.width = `${rect.width}px`;
        dropdown.style.maxWidth = `${Math.min(rect.width, 350)}px`;
      }
    }, 0);
  }, []);

  // Procesar datos
  const sortedEntidades = useMemo(() => {
    if (!extractedData) return [];
    return Array.from(extractedData.entidades).sort((a, b) => a.localeCompare(b, 'es'));
  }, [extractedData]);

  const sortedMunicipios = useMemo(() => {
    if (!extractedData || !filters.entidad) return [];
    const municipios = extractedData.municipiosPorEntidad.get(filters.entidad) || new Set();
    return Array.from(municipios).sort((a, b) => a.localeCompare(b, 'es'));
  }, [extractedData, filters.entidad]);

  const sortedComunidades = useMemo(() => {
    if (!extractedData || !filters.entidad || !filters.municipio) return [];
    const key = `${filters.entidad}|${filters.municipio}`;
    const comunidades = extractedData.comunidadesPorMunicipio.get(key) || new Set();
    return Array.from(comunidades).sort((a, b) => a.localeCompare(b, 'es'));
  }, [extractedData, filters.entidad, filters.municipio]);

  const sortedPueblos = useMemo(() => {
    if (!extractedData) return [];
    return Array.from(extractedData.pueblos).sort((a, b) => a.localeCompare(b, 'es'));
  }, [extractedData]);

  // Filtrar opciones basado en búsqueda
  const filteredEntidades = useMemo(() => {
    if (!searchTerms.entidad) return sortedEntidades;
    const term = searchTerms.entidad.toLowerCase();
    return sortedEntidades.filter(e => e.toLowerCase().includes(term));
  }, [sortedEntidades, searchTerms.entidad]);

  const filteredMunicipios = useMemo(() => {
    if (!searchTerms.municipio) return sortedMunicipios;
    const term = searchTerms.municipio.toLowerCase();
    return sortedMunicipios.filter(m => m.toLowerCase().includes(term));
  }, [sortedMunicipios, searchTerms.municipio]);

  const filteredComunidades = useMemo(() => {
    if (!searchTerms.comunidad) return sortedComunidades;
    const term = searchTerms.comunidad.toLowerCase();
    return sortedComunidades.filter(c => c.toLowerCase().includes(term));
  }, [sortedComunidades, searchTerms.comunidad]);

  const filteredPueblos = useMemo(() => {
    if (!searchTerms.pueblo) return sortedPueblos;
    const term = searchTerms.pueblo.toLowerCase();
    return sortedPueblos.filter(p => p.toLowerCase().includes(term));
  }, [sortedPueblos, searchTerms.pueblo]);

  // Contar elementos filtrados
  const getFilteredCount = useMemo(() => {
    if (!extractedData) return 0;
    
    return extractedData.features.filter(feature => {
      const props = feature.properties || {};
      
      if (filters.entidad && props.NOM_ENT !== filters.entidad) return false;
      if (filters.municipio && props.NOM_MUN !== filters.municipio) return false;
      if (filters.comunidad) {
        const comunidad = props.NOM_COM || props.NOM_LOC;
        if (comunidad !== filters.comunidad) return false;
      }
      if (filters.pueblo && props.Pueblo !== filters.pueblo) return false;
      
      return true;
    }).length;
  }, [extractedData, filters]);

  // Cerrar dropdowns al hacer scroll o redimensionar
  useEffect(() => {
    const closeAllDropdowns = () => {
      setShowDropdowns({
        entidad: false,
        municipio: false,
        comunidad: false,
        pueblo: false
      });
    };

    const handleScroll = (event: Event) => {
      // Cerrar dropdowns en cualquier tipo de scroll
      const target = event.target as Element;
      
      // No cerrar si el scroll es dentro del propio dropdown
      if (target && target.closest('.dropdown-list')) {
        return;
      }
      
      closeAllDropdowns();
    };

    const handleWheel = (event: WheelEvent) => {
      // Cerrar dropdowns al usar la rueda del mouse
      const target = event.target as Element;
      
      // No cerrar si el scroll es dentro del propio dropdown
      if (target && target.closest('.dropdown-list')) {
        return;
      }
      
      closeAllDropdowns();
    };

    const handleResize = () => {
      closeAllDropdowns();
    };

    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Element;
      if (!target.closest('.custom-select') && !target.closest('.dropdown-list')) {
        closeAllDropdowns();
      }
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      // Cerrar dropdowns al presionar Escape
      if (event.key === 'Escape') {
        closeAllDropdowns();
      }
    };

    // Capturar scroll en ventana principal
    window.addEventListener('scroll', handleScroll, true);
    
    // Capturar scroll con rueda del mouse
    window.addEventListener('wheel', handleWheel, true);
    
    // Capturar scroll en el contenedor del sidebar
    const sidebarContent = document.querySelector('.sidebar-content');
    if (sidebarContent) {
      sidebarContent.addEventListener('scroll', handleScroll, true);
      sidebarContent.addEventListener('wheel', handleWheel, true);
    }
    
    // Capturar scroll en cualquier contenedor scrolleable
    document.addEventListener('scroll', handleScroll, true);
    document.addEventListener('wheel', handleWheel, true);
    
    // Otros eventos
    window.addEventListener('resize', handleResize);
    document.addEventListener('click', handleClickOutside);
    document.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('scroll', handleScroll, true);
      window.removeEventListener('wheel', handleWheel, true);
      window.removeEventListener('resize', handleResize);
      document.removeEventListener('click', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('scroll', handleScroll, true);
      document.removeEventListener('wheel', handleWheel, true);
      
      if (sidebarContent) {
        sidebarContent.removeEventListener('scroll', handleScroll, true);
        sidebarContent.removeEventListener('wheel', handleWheel, true);
      }
    };
  }, []);

  // Limpiar filtros dependientes
  useEffect(() => {
    if (filters.entidad) {
      const prevMunicipio = filters.municipio;
      if (prevMunicipio && !sortedMunicipios.includes(prevMunicipio)) {
        setFilters(prev => ({ ...prev, municipio: '', comunidad: '' }));
      }
    }
  }, [filters.entidad, sortedMunicipios]);

  useEffect(() => {
    if (filters.municipio) {
      const prevComunidad = filters.comunidad;
      if (prevComunidad && !sortedComunidades.includes(prevComunidad)) {
        setFilters(prev => ({ ...prev, comunidad: '' }));
      }
    }
  }, [filters.municipio, sortedComunidades]);

  useEffect(() => {
    onFilterChange(filters);
  }, [filters, onFilterChange]);

  const handleFilterChange = (field: keyof FilterState, value: string) => {
    setFilters(prev => {
      const newFilters = { ...prev, [field]: value };
      
      if (field === 'entidad') {
        newFilters.municipio = '';
        newFilters.comunidad = '';
      } else if (field === 'municipio') {
        newFilters.comunidad = '';
      }
      
      return newFilters;
    });
    
    setShowDropdowns(prev => ({ ...prev, [field]: false }));
    setSearchTerms(prev => ({ ...prev, [field]: '' }));
  };

  const handleSearchChange = (field: keyof FilterState, value: string) => {
    setSearchTerms(prev => ({ ...prev, [field]: value }));
    if (field === 'entidad' || field === 'municipio' || field === 'comunidad' || field === 'pueblo') {
      setFilters(prev => ({ ...prev, [field]: value }));
    }
  };

  const clearAllFilters = () => {
    setFilters({
      entidad: '',
      municipio: '',
      comunidad: '',
      pueblo: ''
    });
    setSearchTerms({
      entidad: '',
      municipio: '',
      comunidad: '',
      pueblo: ''
    });
  };

  const handleViewFicha = () => {
    if (!selectedCommunity?.id) {
      alert('No se encontró el ID de la comunidad');
      return;
    }
    onOpenHtmlViewer(selectedCommunity.id, selectedCommunity.nombre);
  };

  const toggleDropdown = (field: keyof typeof showDropdowns) => {
    setShowDropdowns(prev => {
      const newState = { ...prev, [field]: !prev[field] };
      
      // Cerrar otros dropdowns
      Object.keys(newState).forEach(key => {
        if (key !== field) {
          newState[key as keyof typeof newState] = false;
        }
      });
      
      return newState;
    });

    // Posicionar el dropdown si se está abriendo
    if (!showDropdowns[field]) {
      positionDropdown(field);
    }
  };

  // Función para renderizar un dropdown genérico
  const renderDropdown = (
    field: keyof FilterState,
    options: string[],
    placeholder: string,
    disabled: boolean = false
  ) => (
    <div className="filter-group">
      <label>
        {field === 'entidad' ? 'Entidad Federativa' : 
         field === 'municipio' ? 'Municipio' : 
         field === 'comunidad' ? 'Comunidad' : 'Pueblo'}: 
        {filters[field] && <span className="filter-badge">✓</span>}
      </label>
      <div className="custom-select">
        <input
          ref={(el) => { inputRefs.current[field] = el; }}
          type="text"
          value={filters[field] || searchTerms[field]}
          onChange={(e) => handleSearchChange(field, e.target.value)}
          onFocus={() => !disabled && toggleDropdown(field)}
          placeholder={placeholder}
          className="select-input"
          disabled={disabled}
        />
        {showDropdowns[field] && !disabled && (
          <div className={`dropdown-list dropdown-${field}`}>
            <div className="dropdown-item" onClick={() => handleFilterChange(field, '')}>
              <span className="dropdown-clear">
                {field === 'entidad' ? 'Todas las entidades' :
                 field === 'municipio' ? 'Todos los municipios' :
                 field === 'comunidad' ? 'Todas las comunidades' : 'Todos los pueblos'}
              </span>
            </div>
            {options.map(option => (
              <div 
                key={option} 
                className={`dropdown-item ${filters[field] === option ? 'selected' : ''}`}
                onClick={() => handleFilterChange(field, option)}
              >
                {option}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className={`sidebar-container ${isDarkTheme ? 'dark' : 'light'}`}>
      <Sidebar 
        collapsed={collapsed}
        backgroundColor={isDarkTheme ? '#1a1a1a' : '#ffffff'}
        rootStyles={{
          border: 'none',
          height: '100vh',
          position: 'fixed',
          right: 0,
          top: 0,
          zIndex: 1000,
          width: collapsed ? '80px' : '350px',
          transition: 'width 0.3s ease'
        }}
      >
        <div className="sidebar-header">
          <button 
            className="collapse-btn dots-toggle"
            onClick={onToggleCollapse}
            title={collapsed ? 'Expandir' : 'Ocultar'}
          >
            <span className={`dots-icon ${collapsed ? 'vertical' : 'horizontal'}`}>
              <span className="dot"></span>
              <span className="dot"></span>
              <span className="dot"></span>
            </span>
          </button>
          {!collapsed && (
            <>
              <h3>Búsqueda por Comunidad</h3>
              <div className="theme-toggle-container">
                <label className="theme-switch" title={isDarkTheme ? 'Cambiar a tema claro' : 'Cambiar a tema oscuro'}>
                  <input 
                    type="checkbox" 
                    checked={isDarkTheme} 
                    onChange={onThemeToggle}
                    aria-label={isDarkTheme ? 'Activar tema claro' : 'Activar tema oscuro'}
                  />
                  <span className="theme-slider">
                    <span className="theme-icon sun">☀</span>
                    <span className="theme-icon moon">🌜</span>
                  </span>
                </label>
              </div>
            </>
          )}
        </div>

        {!collapsed && (
          <div className="sidebar-content">
            {/* Contador de resultados */}
            {extractedData && (
              <div className="filter-stats">
                <div className="stats-card">
                  <span className="stats-number">{getFilteredCount.toLocaleString()}</span>
                  <span className="stats-label">Localidades encontradas</span>
                </div>
                {(filters.entidad || filters.municipio || filters.comunidad || filters.pueblo) && (
                  <button className="clear-filters-btn" onClick={clearAllFilters}>
                    ✕ Limpiar filtros
                  </button>
                )}
              </div>
            )}

            <Menu>
              <SubMenu label="Filtros de búsqueda" defaultOpen>
                <div className="filter-section">
                  {/* Entidad Federativa */}
                  {renderDropdown(
                    'entidad',
                    filteredEntidades,
                    `Buscar entre ${sortedEntidades.length} entidades...`
                  )}

                  {/* Municipio */}
                  {renderDropdown(
                    'municipio',
                    filteredMunicipios,
                    filters.entidad ? `Buscar entre ${sortedMunicipios.length} municipios...` : 'Seleccione entidad',
                    !filters.entidad
                  )}

                  {/* Comunidad */}
                  {renderDropdown(
                    'comunidad',
                    filteredComunidades,
                    filters.municipio ? `Buscar entre ${sortedComunidades.length} comunidades...` : 'Seleccione municipio',
                    !filters.municipio
                  )}

                  {/* Pueblo */}
                  {renderDropdown(
                    'pueblo',
                    filteredPueblos,
                    `Buscar entre ${sortedPueblos.length} pueblos...`
                  )}
                </div>
              </SubMenu>
            </Menu>

            {/* Resumen de comunidad seleccionada */}
            {selectedCommunity && (
              <div className="community-summary">
                <div className="community-summary-header">
                  <h4>Comunidad Seleccionada</h4>
                  <button 
                    className="close-community-btn"
                    onClick={onClearSelectedCommunity}
                    title="Cerrar información de comunidad"
                  >
                    ✕
                  </button>
                </div>

                <div className="summary-card">
                  <h5>{selectedCommunity.nombre}</h5>
                  <p><strong>Entidad:</strong> {selectedCommunity.entidad}</p>
                  <p><strong>Municipio:</strong> {selectedCommunity.municipio}</p>
                  <p><strong>Pueblo:</strong> {selectedCommunity.pueblo}</p>
                  
                  
                  <div className="summary-actions">
                    <button 
                      className="btn-view-card" 
                      onClick={handleViewFicha}
                      title="Ver ficha completa"
                    >
                      📋 Ver Ficha
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Loading indicator */}
            {!extractedData && (
              <div className="loading-container">
                <div className="loading-spinner"></div>
                <p>Cargando datos del mapa...</p>
              </div>
            )}
          </div>
        )}
      </Sidebar>
    </div>
  );
};

export default CustomSidebar;