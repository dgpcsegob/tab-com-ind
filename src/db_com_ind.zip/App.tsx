import React, { useState } from 'react';
import CustomSidebar from './components/Sidebar/Sidebar';
import Map from './components/Map/Map';
import CommunityCard from './components/CommunityCard/CommunityCard';
import HtmlViewer from './components/HtmlViewer/HtmlViewer';
import './App.css';

interface FilterState {
  entidad: string;
  municipio: string;
  comunidad: string;
  pueblo: string; // AGREGADO
}

interface CommunityData {
  id: string;
  nombre: string;
  entidad: string;
  municipio: string;
  pueblo: string;
  poblacion: number;
  latitud: number;
  longitud: number;
}

// NUEVO: Interface para datos extraídos
interface ExtractedData {
  entidades: Set<string>;
  municipiosPorEntidad: Map<string, Set<string>>;
  comunidadesPorMunicipio: Map<string, Set<string>>;
  pueblos: Set<string>;
  features: any[];
}

const App: React.FC = () => {
  const [layersVisibility, setLayersVisibility] = useState<Record<string, boolean>>({
    LocalidadesSedeINPI: true,
  });

  const [filters, setFilters] = useState<FilterState>({
    entidad: '',
    municipio: '',
    comunidad: '',
    pueblo: '' // AGREGADO
  });

  const [selectedCommunity, setSelectedCommunity] = useState<CommunityData | null>(null);
  const [showCommunityCard, setShowCommunityCard] = useState(false);
  const [isDarkTheme, setIsDarkTheme] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  // Estados para el visor HTML
  const [showHtmlViewer, setShowHtmlViewer] = useState(false);
  const [htmlViewerCommunityId, setHtmlViewerCommunityId] = useState('');
  const [htmlViewerCommunityName, setHtmlViewerCommunityName] = useState('');

  // NUEVO: Estado para datos extraídos del mapa
  const [extractedData, setExtractedData] = useState<ExtractedData | null>(null);

  const handleToggle = (id: string) => {
    setLayersVisibility(prev => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const handleFilterChange = (newFilters: FilterState) => {
    setFilters(newFilters);
    
    // Limpiar comunidad seleccionada si se cambian los filtros
    if (newFilters.comunidad !== filters.comunidad) {
      setSelectedCommunity(null);
      setShowCommunityCard(false);
    }
  };

  const handleCommunityClick = (communityId: string, communityData: CommunityData) => {
    setSelectedCommunity(communityData);
    setShowCommunityCard(true);
  };

  const handleCloseCommunityCard = () => {
    setShowCommunityCard(false);
  };

  const handleThemeToggle = () => {
    setIsDarkTheme(prev => !prev);
  };

  const handleSidebarToggle = () => {
    setSidebarCollapsed(prev => !prev);
  };

  // Función para abrir el visor HTML
  const handleOpenHtmlViewer = (communityId: string, communityName: string) => {
    setHtmlViewerCommunityId(communityId);
    setHtmlViewerCommunityName(communityName);
    setShowHtmlViewer(true);
  };

  // Función para cerrar el visor HTML
  const handleCloseHtmlViewer = () => {
    setShowHtmlViewer(false);
    setHtmlViewerCommunityId('');
    setHtmlViewerCommunityName('');
  };

  // Función para cerrar/limpiar la comunidad seleccionada
  const handleClearSelectedCommunity = () => {
    setSelectedCommunity(null);
    setShowCommunityCard(false);
    // También cerrar el visor HTML si está abierto
    if (showHtmlViewer) {
      setShowHtmlViewer(false);
      setHtmlViewerCommunityId('');
      setHtmlViewerCommunityName('');
    }
  };

  // NUEVO: Manejar datos extraídos del mapa
  const handleDataLoaded = (data: ExtractedData) => {
    setExtractedData(data);
    console.log('Datos cargados en App:', {
      entidades: data.entidades.size,
      pueblos: data.pueblos.size,
      totalFeatures: data.features.length
    });
  };

  // NUEVO: Sincronizar filtros cuando se hace click en el mapa
  const handleFilterChangeFromMap = (patch: { entidad?: string; municipio?: string; localidad?: string }) => {
    // Buscar los valores correctos en los datos extraídos
    if (extractedData && patch.entidad) {
      const entidadMatch = Array.from(extractedData.entidades).find(e => e === patch.entidad);
      if (entidadMatch) {
        setFilters(prev => ({
          ...prev,
          entidad: entidadMatch,
          municipio: patch.municipio || '',
          comunidad: patch.localidad || '',
          pueblo: '' // Reset pueblo cuando se selecciona desde el mapa
        }));
      }
    }
  };

  return (
    <div className={`App ${isDarkTheme ? 'dark-theme' : 'light-theme'}`}>
      {/* Sidebar derecho */}
      <CustomSidebar
        layersVisibility={layersVisibility}
        onToggle={handleToggle}
        onFilterChange={handleFilterChange}
        selectedCommunity={selectedCommunity}
        isDarkTheme={isDarkTheme}
        onThemeToggle={handleThemeToggle}
        collapsed={sidebarCollapsed}
        onToggleCollapse={handleSidebarToggle}
        onOpenHtmlViewer={handleOpenHtmlViewer}
        onClearSelectedCommunity={handleClearSelectedCommunity}
        extractedData={extractedData} // NUEVO: pasar datos extraídos
      />

      {/* Ajustar altura del mapa cuando el HTML viewer está abierto */}
      <div 
        className={`map-container ${sidebarCollapsed ? 'sidebar-collapsed' : 'sidebar-expanded'}`}
        style={{ 
          height: showHtmlViewer ? 'calc(100vh - 300px)' : '100vh',
          transition: 'height 0.3s ease'
        }}
      >
        <Map 
          layersVisibility={layersVisibility}
          filters={filters}
          isDarkTheme={isDarkTheme}
          onCommunityClick={handleCommunityClick}
          onFilterChangeFromMap={handleFilterChangeFromMap} // NUEVO
          onDataLoaded={handleDataLoaded} // NUEVO: callback para recibir datos
        />
      </div>

      {/* Ficha de comunidad */}
      {showCommunityCard && selectedCommunity && (
        <CommunityCard
          isOpen={showCommunityCard}
          onClose={handleCloseCommunityCard}
          communityId={selectedCommunity.id}
          isDarkTheme={isDarkTheme}
        />
      )}

      {/* Visor HTML en la parte inferior */}
      <HtmlViewer
        isOpen={showHtmlViewer}
        communityId={htmlViewerCommunityId}
        communityName={htmlViewerCommunityName}
        onClose={handleCloseHtmlViewer}
        isDarkTheme={isDarkTheme}
      />

      {/* Overlay para sidebar en modo móvil */}
      {!sidebarCollapsed && (
        <div 
          className="sidebar-overlay mobile-only"
          onClick={handleSidebarToggle}
        />
      )}
    </div>
  );
};

export default App;